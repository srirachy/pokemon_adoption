import React from 'react';

const FormSection = ({children}) => {
    return (<section className="formSection">{children}</section>);}

export default FormSection;