import React from 'react';

const DataCell = ({children}) => {
    return (
        <td>{children}</td>
    );
};

export default DataCell;